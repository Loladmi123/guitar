import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import './App.css';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

// Auth Context
const AuthContext = React.createContext();

const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(localStorage.getItem('token'));

  useEffect(() => {
    if (token) {
      axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
      fetchCurrentUser();
    }
  }, [token]);

  const fetchCurrentUser = async () => {
    try {
      const response = await axios.get(`${API}/me`);
      setUser(response.data);
    } catch (error) {
      logout();
    }
  };

  const login = (tokenData, userData) => {
    setToken(tokenData);
    setUser(userData);
    localStorage.setItem('token', tokenData);
    axios.defaults.headers.common['Authorization'] = `Bearer ${tokenData}`;
  };

  const logout = () => {
    setToken(null);
    setUser(null);
    localStorage.removeItem('token');
    delete axios.defaults.headers.common['Authorization'];
  };

  return (
    <AuthContext.Provider value={{ user, token, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

const useAuth = () => {
  const context = React.useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

// Navigation Component
const Navigation = () => {
  const { user, logout } = useAuth();
  const [currentPage, setCurrentPage] = useState('home');

  return (
    <>
      <nav className="nav-premium fixed w-full top-0 z-50 shadow-2xl">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <span className="text-premium-gold text-3xl font-black tracking-tight">
                  🎸 GuitarHub
                  <span className="text-white text-sm font-normal ml-2">PREMIUM</span>
                </span>
              </div>
              <div className="hidden md:block">
                <div className="ml-16 flex items-baseline space-x-2">
                  <button
                    onClick={() => setCurrentPage('home')}
                    className={`px-6 py-3 rounded-full text-base font-semibold transition-all duration-300 ${
                      currentPage === 'home' ? 'nav-link-active' : 'nav-link'
                    }`}
                  >
                    Home
                  </button>
                  <button
                    onClick={() => setCurrentPage('recordings')}
                    className={`px-6 py-3 rounded-full text-base font-semibold transition-all duration-300 ${
                      currentPage === 'recordings' ? 'nav-link-active' : 'nav-link'
                    }`}
                  >
                    Recordings
                  </button>
                  <button
                    onClick={() => setCurrentPage('upload')}
                    className={`px-6 py-3 rounded-full text-base font-semibold transition-all duration-300 ${
                      currentPage === 'upload' ? 'nav-link-active' : 'nav-link'
                    }`}
                  >
                    Upload
                  </button>
                  <button
                    onClick={() => setCurrentPage('chat')}
                    className={`px-6 py-3 rounded-full text-base font-semibold transition-all duration-300 ${
                      currentPage === 'chat' ? 'nav-link-active' : 'nav-link'
                    }`}
                  >
                    Community Chat
                  </button>
                </div>
              </div>
            </div>
            <div className="hidden md:block">
              <div className="ml-6 flex items-center space-x-6">
                {user && (
                  <>
                    <div className="text-right">
                      <div className="text-premium-gold font-semibold text-lg">{user.username}</div>
                      <div className="text-white text-sm opacity-80 capitalize">{user.skill_level} Level</div>
                    </div>
                    <button
                      onClick={logout}
                      className="bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded-full text-base font-semibold transition-all duration-300 hover:shadow-lg"
                    >
                      Logout
                    </button>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      </nav>
      <div className="pt-20">
        <PageRouter currentPage={currentPage} />
      </div>
    </>
  );
};

// Login/Register Component
const AuthForm = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    username: '',
    full_name: '',
    skill_level: 'beginner'
  });
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      const endpoint = isLogin ? 'login' : 'register';
      const response = await axios.post(`${API}/${endpoint}`, formData);
      login(response.data.access_token, response.data.user);
    } catch (error) {
      alert(error.response?.data?.detail || 'An error occurred');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-premium-dark flex items-center justify-center px-6 relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute inset-0 bg-gradient-to-br from-transparent via-yellow-900/5 to-transparent"></div>
      <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-gradient-to-r from-yellow-400/10 to-transparent rounded-full blur-3xl"></div>
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-gradient-to-l from-yellow-600/10 to-transparent rounded-full blur-3xl"></div>
      
      <div className="max-w-md w-full space-y-8 form-premium rounded-2xl p-10 shadow-2xl relative z-10">
        <div className="text-center">
          <h2 className="text-4xl font-black text-premium-gold mb-4">
            {isLogin ? 'Welcome Back' : 'Join the Elite'}
          </h2>
          <p className="text-xl text-white opacity-90">
            {isLogin ? 'Sign in to your premium account' : 'Create your premium guitar community account'}
          </p>
          <div className="mt-4 h-1 w-20 bg-premium-gold mx-auto rounded-full"></div>
        </div>
        
        <form className="mt-12 space-y-6" onSubmit={handleSubmit}>
          <div className="space-y-5">
            {!isLogin && (
              <>
                <div>
                  <label className="block text-premium-gold text-sm font-bold mb-2">Username</label>
                  <input
                    type="text"
                    required
                    className="input-premium appearance-none rounded-xl relative block w-full px-4 py-4 text-lg focus:z-10"
                    placeholder="Your unique username"
                    value={formData.username}
                    onChange={(e) => setFormData({...formData, username: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block text-premium-gold text-sm font-bold mb-2">Full Name</label>
                  <input
                    type="text"
                    required
                    className="input-premium appearance-none rounded-xl relative block w-full px-4 py-4 text-lg focus:z-10"
                    placeholder="Your full name"
                    value={formData.full_name}
                    onChange={(e) => setFormData({...formData, full_name: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block text-premium-gold text-sm font-bold mb-2">Skill Level</label>
                  <select
                    className="input-premium appearance-none rounded-xl relative block w-full px-4 py-4 text-lg focus:z-10"
                    value={formData.skill_level}
                    onChange={(e) => setFormData({...formData, skill_level: e.target.value})}
                  >
                    <option value="beginner">Beginner</option>
                    <option value="intermediate">Intermediate</option>
                    <option value="advanced">Advanced</option>
                  </select>
                </div>
              </>
            )}
            <div>
              <label className="block text-premium-gold text-sm font-bold mb-2">Email Address</label>
              <input
                type="email"
                required
                className="input-premium appearance-none rounded-xl relative block w-full px-4 py-4 text-lg focus:z-10"
                placeholder="Your email address"
                value={formData.email}
                onChange={(e) => setFormData({...formData, email: e.target.value})}
              />
            </div>
            <div>
              <label className="block text-premium-gold text-sm font-bold mb-2">Password</label>
              <input
                type="password"
                required
                className="input-premium appearance-none rounded-xl relative block w-full px-4 py-4 text-lg focus:z-10"
                placeholder="Your secure password"
                value={formData.password}
                onChange={(e) => setFormData({...formData, password: e.target.value})}
              />
            </div>
          </div>

          <div className="pt-4">
            <button
              type="submit"
              disabled={loading}
              className="btn-premium-gold group relative w-full flex justify-center py-4 px-6 text-lg font-bold rounded-xl disabled:opacity-50"
            >
              {loading ? 'Processing...' : (isLogin ? 'Sign In' : 'Create Account')}
            </button>
          </div>

          <div className="text-center pt-4">
            <button
              type="button"
              className="text-premium-gold hover:text-yellow-300 text-lg font-semibold transition-colors duration-300"
              onClick={() => setIsLogin(!isLogin)}
            >
              {isLogin ? "Don't have an account? Join now" : "Already have an account? Sign in"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

// Home Component
const Home = () => {
  return (
    <div className="bg-premium-dark">
      {/* Hero Section */}
      <div 
        className="hero-premium relative flex items-center justify-center"
        style={{
          backgroundImage: `linear-gradient(rgba(0,0,0,0.7), rgba(0,0,0,0.7)), url('https://images.pexels.com/photos/8190785/pexels-photo-8190785.jpeg')`
        }}
      >
        <div className="text-center max-w-6xl mx-auto px-6 relative z-10">
          <div className="float-animation">
            <h1 className="text-premium-title text-premium-gold mb-8">
              Master Guitar
              <br />
              <span className="text-white">Together</span>
            </h1>
          </div>
          <p className="text-premium-subtitle text-white mb-12 max-w-3xl mx-auto leading-relaxed">
            Join the world's most exclusive guitar learning community. Upload your masterpieces, 
            discover incredible music, and connect with fellow virtuosos.
          </p>
          <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
            <button className="btn-premium-gold py-4 px-10 rounded-full text-xl font-bold">
              Start Your Journey
            </button>
            <button className="btn-premium-outline py-4 px-10 rounded-full text-xl font-bold">
              Explore Masterpieces
            </button>
          </div>
        </div>
      </div>
      
      {/* Features Section */}
      <div className="section-premium bg-premium-dark">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-20">
            <h2 className="text-5xl font-black text-premium-gold mb-6">
              Why Choose GuitarHub Premium?
            </h2>
            <div className="h-1 w-32 bg-premium-gold mx-auto rounded-full"></div>
          </div>
          
          <div className="grid lg:grid-cols-3 gap-12">
            <div className="bg-premium-card premium-card rounded-2xl p-10 text-center">
              <div className="text-6xl mb-8">🎵</div>
              <h3 className="text-2xl font-bold text-premium-gold mb-6">Share Your Artistry</h3>
              <p className="text-white text-lg leading-relaxed opacity-90">
                Upload high-quality audio and video recordings of your guitar performances. 
                Showcase your talent to a discerning community of musicians.
              </p>
            </div>
            
            <div className="bg-premium-card premium-card rounded-2xl p-10 text-center">
              <div className="text-6xl mb-8">🔍</div>
              <h3 className="text-2xl font-bold text-premium-gold mb-6">Discover Excellence</h3>
              <p className="text-white text-lg leading-relaxed opacity-90">
                Explore curated recordings by genre, difficulty level, and style. 
                Find inspiration from the world's most passionate guitarists.
              </p>
            </div>
            
            <div className="bg-premium-card premium-card rounded-2xl p-10 text-center">
              <div className="text-6xl mb-8">💬</div>
              <h3 className="text-2xl font-bold text-premium-gold mb-6">Elite Community</h3>
              <p className="text-white text-lg leading-relaxed opacity-90">
                Join real-time conversations with fellow guitar enthusiasts. 
                Share techniques, get feedback, and build lasting musical connections.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Section */}
      <div className="section-premium bg-black/50">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8 text-center">
            <div className="premium-card">
              <div className="text-4xl font-black text-premium-gold mb-2">10K+</div>
              <div className="text-white text-lg opacity-90">Active Musicians</div>
            </div>
            <div className="premium-card">
              <div className="text-4xl font-black text-premium-gold mb-2">50K+</div>
              <div className="text-white text-lg opacity-90">Recordings Shared</div>
            </div>
            <div className="premium-card">
              <div className="text-4xl font-black text-premium-gold mb-2">100K+</div>
              <div className="text-white text-lg opacity-90">Hours of Music</div>
            </div>
            <div className="premium-card">
              <div className="text-4xl font-black text-premium-gold mb-2">24/7</div>
              <div className="text-white text-lg opacity-90">Community Support</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// Recordings Component
const Recordings = () => {
  const [recordings, setRecordings] = useState([]);
  const [filters, setFilters] = useState({
    genre: '',
    difficulty: '',
    song_type: '',
    search: ''
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchRecordings();
  }, [filters]);

  const fetchRecordings = async () => {
    try {
      const params = new URLSearchParams();
      Object.entries(filters).forEach(([key, value]) => {
        if (value) params.append(key, value);
      });
      
      const response = await axios.get(`${API}/recordings?${params}`);
      setRecordings(response.data);
    } catch (error) {
      console.error('Error fetching recordings:', error);
    } finally {
      setLoading(false);
    }
  };

  const likeRecording = async (recordingId) => {
    try {
      await axios.post(`${API}/recordings/${recordingId}/like`);
      fetchRecordings();
    } catch (error) {
      console.error('Error liking recording:', error);
    }
  };

  return (
    <div className="min-h-screen bg-premium-dark section-premium">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h1 className="text-5xl font-black text-premium-gold mb-6">Premium Recordings</h1>
          <p className="text-2xl text-white opacity-90">Discover masterpieces from our community</p>
          <div className="h-1 w-32 bg-premium-gold mx-auto rounded-full mt-6"></div>
        </div>
        
        {/* Enhanced Filters */}
        <div className="bg-premium-card rounded-2xl p-8 mb-12">
          <div className="grid lg:grid-cols-4 gap-6">
            <div>
              <label className="block text-premium-gold text-sm font-bold mb-2">Search Recordings</label>
              <input
                type="text"
                placeholder="Search by title or description..."
                className="input-premium w-full rounded-xl px-4 py-3 text-lg"
                value={filters.search}
                onChange={(e) => setFilters({...filters, search: e.target.value})}
              />
            </div>
            <div>
              <label className="block text-premium-gold text-sm font-bold mb-2">Genre</label>
              <select
                className="input-premium w-full rounded-xl px-4 py-3 text-lg"
                value={filters.genre}
                onChange={(e) => setFilters({...filters, genre: e.target.value})}
              >
                <option value="">All Genres</option>
                <option value="rock">Rock</option>
                <option value="blues">Blues</option>
                <option value="classical">Classical</option>
                <option value="jazz">Jazz</option>
                <option value="country">Country</option>
                <option value="folk">Folk</option>
              </select>
            </div>
            <div>
              <label className="block text-premium-gold text-sm font-bold mb-2">Difficulty</label>
              <select
                className="input-premium w-full rounded-xl px-4 py-3 text-lg"
                value={filters.difficulty}
                onChange={(e) => setFilters({...filters, difficulty: e.target.value})}
              >
                <option value="">All Levels</option>
                <option value="beginner">Beginner</option>
                <option value="intermediate">Intermediate</option>
                <option value="advanced">Advanced</option>
              </select>
            </div>
            <div>
              <label className="block text-premium-gold text-sm font-bold mb-2">Type</label>
              <select
                className="input-premium w-full rounded-xl px-4 py-3 text-lg"
                value={filters.song_type}
                onChange={(e) => setFilters({...filters, song_type: e.target.value})}
              >
                <option value="">All Types</option>
                <option value="original">Original</option>
                <option value="cover">Cover</option>
              </select>
            </div>
          </div>
        </div>

        {/* Recordings Grid */}
        {loading ? (
          <div className="text-center text-white text-xl">
            <div className="premium-pulse">Loading premium recordings...</div>
          </div>
        ) : (
          <div className="grid lg:grid-cols-2 xl:grid-cols-3 gap-8">
            {recordings.map((recording) => (
              <div key={recording.id} className="bg-premium-card premium-card rounded-2xl p-8">
                <div className="flex justify-between items-start mb-6">
                  <div className="flex-1">
                    <h3 className="text-2xl font-bold text-white mb-2">{recording.title}</h3>
                    <p className="text-premium-gold text-lg font-semibold">by {recording.user?.username}</p>
                  </div>
                  <span className="badge-premium">
                    {recording.file_type.toUpperCase()}
                  </span>
                </div>
                
                <p className="text-white text-lg mb-6 opacity-90 leading-relaxed">{recording.description}</p>
                
                <div className="flex flex-wrap gap-3 mb-6">
                  <span className="bg-blue-600 text-white px-3 py-2 rounded-full text-sm font-semibold">{recording.genre}</span>
                  <span className="bg-green-600 text-white px-3 py-2 rounded-full text-sm font-semibold">{recording.difficulty}</span>
                  <span className="bg-purple-600 text-white px-3 py-2 rounded-full text-sm font-semibold">{recording.song_type}</span>
                </div>
                
                {recording.file_type === 'audio' ? (
                  <audio controls className="w-full mb-6">
                    <source src={`${BACKEND_URL}/api/recordings/${recording.id}/file`} />
                  </audio>
                ) : (
                  <video controls className="w-full mb-6 rounded-xl">
                    <source src={`${BACKEND_URL}/api/recordings/${recording.id}/file`} />
                  </video>
                )}
                
                <div className="flex justify-between items-center">
                  <button
                    onClick={() => likeRecording(recording.id)}
                    className="like-button flex items-center gap-3 text-white hover:text-premium-gold font-semibold text-lg"
                  >
                    ❤️ {recording.likes}
                  </button>
                  <span className="text-white opacity-70 text-base">
                    {new Date(recording.created_at).toLocaleDateString()}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

// Upload Component
const Upload = () => {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    genre: '',
    difficulty: '',
    song_type: ''
  });
  const [file, setFile] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!file) {
      alert('Please select a file');
      return;
    }
    
    setUploading(true);
    const formDataToSend = new FormData();
    formDataToSend.append('file', file);
    Object.entries(formData).forEach(([key, value]) => {
      formDataToSend.append(key, value);
    });

    try {
      await axios.post(`${API}/recordings/upload`, formDataToSend, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
        onUploadProgress: (progressEvent) => {
          const progress = Math.round((progressEvent.loaded * 100) / progressEvent.total);
          setUploadProgress(progress);
        }
      });
      
      alert('Recording uploaded successfully!');
      setFormData({
        title: '',
        description: '',
        genre: '',
        difficulty: '',
        song_type: ''
      });
      setFile(null);
    } catch (error) {
      alert('Error uploading recording');
    } finally {
      setUploading(false);
      setUploadProgress(0);
    }
  };

  return (
    <div className="min-h-screen bg-premium-dark section-premium">
      <div className="max-w-4xl mx-auto px-6">
        <div className="text-center mb-16">
          <h1 className="text-5xl font-black text-premium-gold mb-6">Share Your Masterpiece</h1>
          <p className="text-2xl text-white opacity-90">Upload your guitar recording to inspire others</p>
          <div className="h-1 w-32 bg-premium-gold mx-auto rounded-full mt-6"></div>
        </div>
        
        <div className="bg-premium-card rounded-2xl p-12">
          <form onSubmit={handleSubmit} className="space-y-8">
            <div>
              <label className="block text-premium-gold text-lg font-bold mb-3">
                Recording Title
              </label>
              <input
                type="text"
                required
                className="input-premium w-full px-4 py-4 rounded-xl text-lg"
                placeholder="Give your recording a captivating title..."
                value={formData.title}
                onChange={(e) => setFormData({...formData, title: e.target.value})}
              />
            </div>
            
            <div>
              <label className="block text-premium-gold text-lg font-bold mb-3">
                Description
              </label>
              <textarea
                className="input-premium w-full px-4 py-4 rounded-xl text-lg h-32"
                placeholder="Tell us about your recording, inspiration, or technique..."
                value={formData.description}
                onChange={(e) => setFormData({...formData, description: e.target.value})}
              />
            </div>
            
            <div className="grid md:grid-cols-3 gap-6">
              <div>
                <label className="block text-premium-gold text-lg font-bold mb-3">
                  Genre
                </label>
                <select
                  required
                  className="input-premium w-full px-4 py-4 rounded-xl text-lg"
                  value={formData.genre}
                  onChange={(e) => setFormData({...formData, genre: e.target.value})}
                >
                  <option value="">Select Genre</option>
                  <option value="rock">Rock</option>
                  <option value="blues">Blues</option>
                  <option value="classical">Classical</option>
                  <option value="jazz">Jazz</option>
                  <option value="country">Country</option>
                  <option value="folk">Folk</option>
                </select>
              </div>
              
              <div>
                <label className="block text-premium-gold text-lg font-bold mb-3">
                  Difficulty
                </label>
                <select
                  required
                  className="input-premium w-full px-4 py-4 rounded-xl text-lg"
                  value={formData.difficulty}
                  onChange={(e) => setFormData({...formData, difficulty: e.target.value})}
                >
                  <option value="">Select Difficulty</option>
                  <option value="beginner">Beginner</option>
                  <option value="intermediate">Intermediate</option>
                  <option value="advanced">Advanced</option>
                </select>
              </div>
              
              <div>
                <label className="block text-premium-gold text-lg font-bold mb-3">
                  Song Type
                </label>
                <select
                  required
                  className="input-premium w-full px-4 py-4 rounded-xl text-lg"
                  value={formData.song_type}
                  onChange={(e) => setFormData({...formData, song_type: e.target.value})}
                >
                  <option value="">Select Type</option>
                  <option value="original">Original</option>
                  <option value="cover">Cover</option>
                </select>
              </div>
            </div>
            
            <div>
              <label className="block text-premium-gold text-lg font-bold mb-3">
                Audio/Video File
              </label>
              <input
                type="file"
                accept="audio/*,video/*"
                required
                className="w-full px-4 py-4 rounded-xl"
                onChange={(e) => setFile(e.target.files[0])}
              />
              <p className="text-white text-base mt-3 opacity-80">
                Supported formats: MP3, WAV, MP4, AVI, MOV (Max size: 100MB)
              </p>
            </div>
            
            {uploading && (
              <div className="progress-premium w-full h-3 rounded-full">
                <div 
                  className="progress-bar-premium h-3 rounded-full transition-all duration-300"
                  style={{width: `${uploadProgress}%`}}
                ></div>
              </div>
            )}
            
            <button
              type="submit"
              disabled={uploading}
              className="btn-premium-gold w-full font-bold py-4 px-6 rounded-xl text-xl disabled:opacity-50"
            >
              {uploading ? `Uploading... ${uploadProgress}%` : 'Upload Your Masterpiece'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

// Chat Component
const Chat = () => {
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [ws, setWs] = useState(null);
  const { user } = useAuth();
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    fetchMessages();
    
    // WebSocket connection - use secure websocket for HTTPS backend
    const wsUrl = BACKEND_URL.replace('https://', 'wss://').replace('http://', 'ws://');
    const websocket = new WebSocket(`${wsUrl}/api/ws/chat`);
    
    websocket.onopen = () => {
      console.log('WebSocket connected');
    };
    
    websocket.onmessage = (event) => {
      const message = JSON.parse(event.data);
      setMessages(prev => [...prev, message]);
    };
    
    websocket.onerror = (error) => {
      console.error('WebSocket error:', error);
    };
    
    websocket.onclose = () => {
      console.log('WebSocket disconnected');
    };
    
    setWs(websocket);
    
    return () => {
      if (websocket.readyState === WebSocket.OPEN) {
        websocket.close();
      }
    };
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const fetchMessages = async () => {
    try {
      const response = await axios.get(`${API}/chat/messages`);
      setMessages(response.data);
    } catch (error) {
      console.error('Error fetching messages:', error);
    }
  };

  const sendMessage = (e) => {
    e.preventDefault();
    if (!newMessage.trim() || !ws) return;
    
    ws.send(JSON.stringify({
      user_id: user.id,
      username: user.username,
      message: newMessage.trim()
    }));
    
    setNewMessage('');
  };

  return (
    <div className="min-h-screen bg-premium-dark section-premium">
      <div className="max-w-6xl mx-auto px-6">
        <div className="text-center mb-12">
          <h1 className="text-5xl font-black text-premium-gold mb-6">Premium Community Chat</h1>
          <p className="text-2xl text-white opacity-90">Connect with fellow guitar virtuosos</p>
          <div className="h-1 w-32 bg-premium-gold mx-auto rounded-full mt-6"></div>
        </div>
        
        <div className="chat-container rounded-2xl overflow-hidden">
          <div className="h-96 overflow-y-auto p-8 space-y-6 premium-scrollbar">
            {messages.map((message, index) => (
              <div key={`${message.id}-${index}`} className="flex flex-col">
                <div className="flex items-center gap-3 mb-2">
                  <span className="font-bold text-premium-gold text-lg">{message.username}</span>
                  <span className="text-white opacity-60 text-base">
                    {new Date(message.timestamp).toLocaleTimeString()}
                  </span>
                </div>
                <div className="message-bubble text-white p-4 max-w-2xl text-lg leading-relaxed">
                  {message.message}
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>
          
          <form onSubmit={sendMessage} className="p-8 border-t border-yellow-500/20">
            <div className="flex gap-4">
              <input
                type="text"
                placeholder="Share your thoughts with the community..."
                className="input-premium flex-1 px-4 py-4 rounded-xl text-lg"
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
              />
              <button
                type="submit"
                className="btn-premium-gold px-8 py-4 rounded-xl font-bold text-lg"
              >
                Send
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

// Page Router
const PageRouter = ({ currentPage }) => {
  switch (currentPage) {
    case 'recordings':
      return <Recordings />;
    case 'upload':
      return <Upload />;
    case 'chat':
      return <Chat />;
    default:
      return <Home />;
  }
};

// Main App
function App() {
  const { user } = useAuth();

  if (!user) {
    return <AuthForm />;
  }

  return (
    <div className="App">
      <Navigation />
    </div>
  );
}

// App with Auth Provider
export default function AppWithAuth() {
  return (
    <AuthProvider>
      <App />
    </AuthProvider>
  );
}
