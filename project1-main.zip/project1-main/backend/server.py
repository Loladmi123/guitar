from fastapi import FastAPI, APIRouter, HTTPException, UploadFile, File, Form, Depends, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field
from typing import List, Optional
import uuid
from datetime import datetime, timedelta
import jwt
from passlib.context import CryptContext
import shutil
import aiofiles
from fastapi import WebSocket, WebSocketDisconnect
import json

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# Create the main app
app = FastAPI()
api_router = APIRouter(prefix="/api")

# Security
security = HTTPBearer()
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
SECRET_KEY = "your-secret-key-here"
ALGORITHM = "HS256"

# File upload settings
UPLOAD_DIR = Path("uploads")
UPLOAD_DIR.mkdir(exist_ok=True)

# WebSocket connection manager
class ConnectionManager:
    def __init__(self):
        self.active_connections: List[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)

    def disconnect(self, websocket: WebSocket):
        self.active_connections.remove(websocket)

    async def send_personal_message(self, message: str, websocket: WebSocket):
        await websocket.send_text(message)

    async def broadcast(self, message: str):
        for connection in self.active_connections:
            try:
                await connection.send_text(message)
            except:
                pass

manager = ConnectionManager()

# Models
class User(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    username: str
    email: str
    full_name: str
    bio: Optional[str] = ""
    skill_level: str  # beginner, intermediate, advanced
    created_at: datetime = Field(default_factory=datetime.utcnow)

class UserCreate(BaseModel):
    username: str
    email: str
    password: str
    full_name: str
    skill_level: str = "beginner"

class UserLogin(BaseModel):
    email: str
    password: str

class Recording(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str
    title: str
    description: Optional[str] = ""
    genre: str
    difficulty: str
    song_type: str  # original, cover
    filename: str
    file_type: str  # audio, video
    duration: Optional[int] = None
    likes: int = 0
    created_at: datetime = Field(default_factory=datetime.utcnow)

class RecordingCreate(BaseModel):
    title: str
    description: Optional[str] = ""
    genre: str
    difficulty: str
    song_type: str

class ChatMessage(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str
    username: str
    message: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)

class Like(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str
    recording_id: str
    created_at: datetime = Field(default_factory=datetime.utcnow)

# Auth utilities
def create_access_token(data: dict):
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(hours=24)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password):
    return pwd_context.hash(password)

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    try:
        payload = jwt.decode(credentials.credentials, SECRET_KEY, algorithms=[ALGORITHM])
        email: str = payload.get("sub")
        if email is None:
            raise HTTPException(status_code=401, detail="Invalid token")
        user = await db.users.find_one({"email": email})
        if user is None:
            raise HTTPException(status_code=401, detail="User not found")
        return User(**user)
    except jwt.PyJWTError:
        raise HTTPException(status_code=401, detail="Invalid token")

# Routes
@api_router.post("/register")
async def register(user_data: UserCreate):
    # Check if user exists
    existing_user = await db.users.find_one({"email": user_data.email})
    if existing_user:
        raise HTTPException(status_code=400, detail="Email already registered")
    
    existing_username = await db.users.find_one({"username": user_data.username})
    if existing_username:
        raise HTTPException(status_code=400, detail="Username already taken")
    
    # Create user
    hashed_password = get_password_hash(user_data.password)
    user = User(
        username=user_data.username,
        email=user_data.email,
        full_name=user_data.full_name,
        skill_level=user_data.skill_level
    )
    
    user_dict = user.dict()
    user_dict["password"] = hashed_password
    
    await db.users.insert_one(user_dict)
    
    # Create token
    access_token = create_access_token(data={"sub": user.email})
    return {"access_token": access_token, "token_type": "bearer", "user": user}

@api_router.post("/login")
async def login(user_data: UserLogin):
    user = await db.users.find_one({"email": user_data.email})
    if not user or not verify_password(user_data.password, user["password"]):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    access_token = create_access_token(data={"sub": user["email"]})
    user_obj = User(**user)
    return {"access_token": access_token, "token_type": "bearer", "user": user_obj}

@api_router.get("/me")
async def get_me(current_user: User = Depends(get_current_user)):
    return current_user

@api_router.post("/recordings/upload")
async def upload_recording(
    file: UploadFile = File(...),
    title: str = Form(...),
    description: str = Form(""),
    genre: str = Form(...),
    difficulty: str = Form(...),
    song_type: str = Form(...),
    current_user: User = Depends(get_current_user)
):
    # Validate file type
    allowed_types = ["audio/mpeg", "audio/wav", "audio/mp3", "video/mp4", "video/avi", "video/mov"]
    if file.content_type not in allowed_types:
        raise HTTPException(status_code=400, detail="File type not supported")
    
    # Generate filename
    file_extension = file.filename.split(".")[-1]
    filename = f"{uuid.uuid4()}.{file_extension}"
    file_path = UPLOAD_DIR / filename
    
    # Save file
    async with aiofiles.open(file_path, 'wb') as out_file:
        content = await file.read()
        await out_file.write(content)
    
    # Create recording record
    file_type = "audio" if file.content_type.startswith("audio") else "video"
    recording = Recording(
        user_id=current_user.id,
        title=title,
        description=description,
        genre=genre,
        difficulty=difficulty,
        song_type=song_type,
        filename=filename,
        file_type=file_type
    )
    
    await db.recordings.insert_one(recording.dict())
    return recording

@api_router.get("/recordings")
async def get_recordings(
    genre: Optional[str] = None,
    difficulty: Optional[str] = None,
    song_type: Optional[str] = None,
    search: Optional[str] = None
):
    query = {}
    if genre:
        query["genre"] = genre
    if difficulty:
        query["difficulty"] = difficulty
    if song_type:
        query["song_type"] = song_type
    if search:
        query["$or"] = [
            {"title": {"$regex": search, "$options": "i"}},
            {"description": {"$regex": search, "$options": "i"}}
        ]
    
    recordings = await db.recordings.find(query).sort("created_at", -1).to_list(100)
    
    # Get user info for each recording
    for recording in recordings:
        user = await db.users.find_one({"id": recording["user_id"]})
        recording["user"] = {"username": user["username"], "full_name": user["full_name"]} if user else None
    
    return [Recording(**recording) for recording in recordings]

@api_router.get("/recordings/{recording_id}")
async def get_recording(recording_id: str):
    recording = await db.recordings.find_one({"id": recording_id})
    if not recording:
        raise HTTPException(status_code=404, detail="Recording not found")
    
    user = await db.users.find_one({"id": recording["user_id"]})
    recording["user"] = {"username": user["username"], "full_name": user["full_name"]} if user else None
    
    return Recording(**recording)

@api_router.get("/recordings/{recording_id}/file")
async def get_recording_file(recording_id: str):
    recording = await db.recordings.find_one({"id": recording_id})
    if not recording:
        raise HTTPException(status_code=404, detail="Recording not found")
    
    file_path = UPLOAD_DIR / recording["filename"]
    if not file_path.exists():
        raise HTTPException(status_code=404, detail="File not found")
    
    return FileResponse(file_path)

@api_router.post("/recordings/{recording_id}/like")
async def like_recording(recording_id: str, current_user: User = Depends(get_current_user)):
    # Check if already liked
    existing_like = await db.likes.find_one({"user_id": current_user.id, "recording_id": recording_id})
    if existing_like:
        # Unlike
        await db.likes.delete_one({"user_id": current_user.id, "recording_id": recording_id})
        await db.recordings.update_one({"id": recording_id}, {"$inc": {"likes": -1}})
        return {"liked": False}
    else:
        # Like
        like = Like(user_id=current_user.id, recording_id=recording_id)
        await db.likes.insert_one(like.dict())
        await db.recordings.update_one({"id": recording_id}, {"$inc": {"likes": 1}})
        return {"liked": True}

@api_router.get("/chat/messages")
async def get_chat_messages():
    messages = await db.chat_messages.find().sort("timestamp", -1).limit(50).to_list(50)
    return [ChatMessage(**msg) for msg in reversed(messages)]

@api_router.websocket("/ws/chat")
async def websocket_chat(websocket: WebSocket):
    await manager.connect(websocket)
    try:
        while True:
            data = await websocket.receive_text()
            message_data = json.loads(data)
            
            # Create chat message
            chat_message = ChatMessage(
                user_id=message_data["user_id"],
                username=message_data["username"],
                message=message_data["message"]
            )
            
            # Save to database
            await db.chat_messages.insert_one(chat_message.dict())
            
            # Broadcast to all connected clients
            broadcast_data = {
                "id": chat_message.id,
                "user_id": chat_message.user_id,
                "username": chat_message.username,
                "message": chat_message.message,
                "timestamp": chat_message.timestamp.isoformat()
            }
            await manager.broadcast(json.dumps(broadcast_data))
    except WebSocketDisconnect:
        manager.disconnect(websocket)
    except Exception as e:
        logger.error(f"WebSocket error: {e}")
        manager.disconnect(websocket)

# Serve uploaded files
app.mount("/uploads", StaticFiles(directory="uploads"), name="uploads")

# Include router
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
